<?php

namespace hey\EventBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Event
 *
 * @ORM\Table(name="event")
 * @ORM\Entity(repositoryClass="hey\EventBundle\Repository\EventRepository")
 */
class Event
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=255)
     */
    private $nom;

    /**
     * @var string
     *
     * @ORM\Column(name="prix", type="string", length=255)
     */
    private $prix;

    /**
     * @var string
     *
     * @ORM\Column(name="img", type="string", length=255)
     */
    private $img;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="datetime")
     */
    private $date;

    function __construct(){
      $this->date = new \DateTime();
    }

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text")
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="link_site", type="string", length=255)
     */
    private $linkSite;

    /**
     * @var string
     *
     * @ORM\Column(name="link_facebook", type="string", length=255)
     */
    private $linkFacebook;

    /**
     * @var string
     *
     * @ORM\Column(name="link_twiter", type="string", length=255)
     */
    private $linkTwiter;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     * @return Event
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set prix
     *
     * @param string $prix
     * @return Event
     */
    public function setPrix($prix)
    {
        $this->prix = $prix;

        return $this;
    }

    /**
     * Get prix
     *
     * @return string
     */
    public function getPrix()
    {
        return $this->prix;
    }

    /**
     * Set img
     *
     * @param string $img
     * @return Event
     */
    public function setImg($img)
    {
        $this->img = $img;

        return $this;
    }

    /**
     * Get img
     *
     * @return string
     */
    public function getImg()
    {
        return $this->img;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     * @return Event
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Event
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set linkSite
     *
     * @param string $linkSite
     * @return Event
     */
    public function setLinkSite($linkSite)
    {
        $this->linkSite = $linkSite;

        return $this;
    }

    /**
     * Get linkSite
     *
     * @return string
     */
    public function getLinkSite()
    {
        return $this->linkSite;
    }

    /**
     * Set linkFacebook
     *
     * @param string $linkFacebook
     * @return Event
     */
    public function setLinkFacebook($linkFacebook)
    {
        $this->linkFacebook = $linkFacebook;

        return $this;
    }

    /**
     * Get linkFacebook
     *
     * @return string
     */
    public function getLinkFacebook()
    {
        return $this->linkFacebook;
    }

    /**
     * Set linkTwiter
     *
     * @param string $linkTwiter
     * @return Event
     */
    public function setLinkTwiter($linkTwiter)
    {
        $this->linkTwiter = $linkTwiter;

        return $this;
    }

    /**
     * Get linkTwiter
     *
     * @return string
     */
    public function getLinkTwiter()
    {
        return $this->linkTwiter;
    }
}
