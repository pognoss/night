<?php

namespace hey\EventBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use hey\EventBundle\Entity\Event;
use hey\EventBundle\Form\EventType;

class DefaultController extends Controller
{
    public function indexAction()
    {
        $em = $this->getDoctrine()->getEntityManager();
        $e = new Event();
        $form= $this->createForm(new EventType(), $e);

        $req = $this->getRequest();
        if($req->isMethod('POST')){
          $form->submit($req);
          $e = $form->getData();
          $em->persist($e);
          $em->flush();

          return $this->redirect($this->generateUrl("event_homepage"));
        }

        return $this->render('EventBundle:Default:index.html.twig',
          array('form'=>$form->createView())
        );
    }
}
