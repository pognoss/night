<?php

namespace hey\EventBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EventBundle extends Bundle
{
}
