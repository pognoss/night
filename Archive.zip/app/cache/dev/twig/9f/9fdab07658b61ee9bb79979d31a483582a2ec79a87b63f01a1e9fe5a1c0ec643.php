<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_ecb44740844b6844246550b76cda47f847cec671ffd27cd7a1f3476daabbc282 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e61cfcb76c7e87262ce9e68e9ca8679bcb5a5a9db21cbaccc7c9a5fc8066ba38 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e61cfcb76c7e87262ce9e68e9ca8679bcb5a5a9db21cbaccc7c9a5fc8066ba38->enter($__internal_e61cfcb76c7e87262ce9e68e9ca8679bcb5a5a9db21cbaccc7c9a5fc8066ba38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_e61cfcb76c7e87262ce9e68e9ca8679bcb5a5a9db21cbaccc7c9a5fc8066ba38->leave($__internal_e61cfcb76c7e87262ce9e68e9ca8679bcb5a5a9db21cbaccc7c9a5fc8066ba38_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
", "@Framework/Form/number_widget.html.php", "/Applications/MAMP/htdocs/hey/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/number_widget.html.php");
    }
}
