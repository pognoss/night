<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_5049ac929a3dad8710d0ee0f0cb8934998fbe00dc8c985512e58286a4167784a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2621dc26c7ac0c3061d9f3b04ac9912793eb4e6750cd72b9bc08e2220744c2b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2621dc26c7ac0c3061d9f3b04ac9912793eb4e6750cd72b9bc08e2220744c2b1->enter($__internal_2621dc26c7ac0c3061d9f3b04ac9912793eb4e6750cd72b9bc08e2220744c2b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_2621dc26c7ac0c3061d9f3b04ac9912793eb4e6750cd72b9bc08e2220744c2b1->leave($__internal_2621dc26c7ac0c3061d9f3b04ac9912793eb4e6750cd72b9bc08e2220744c2b1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
", "@Framework/Form/search_widget.html.php", "/Applications/MAMP/htdocs/hey/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/search_widget.html.php");
    }
}
