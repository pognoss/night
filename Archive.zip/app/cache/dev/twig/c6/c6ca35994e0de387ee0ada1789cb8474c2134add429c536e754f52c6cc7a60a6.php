<?php

/* EventBundle:Default:index.html.twig */
class __TwigTemplate_9af68590f3e06220c56e2d1eea526e2cc054f0a0a48cd354afa0b2cb364c5063 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_00e43718ac8980fc5e6e3ab9eb412473fd278f1ab77b5575c40a1726b1dd285c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_00e43718ac8980fc5e6e3ab9eb412473fd278f1ab77b5575c40a1726b1dd285c->enter($__internal_00e43718ac8980fc5e6e3ab9eb412473fd278f1ab77b5575c40a1726b1dd285c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EventBundle:Default:index.html.twig"));

        // line 1
        echo "Hello World!


<form action=\"\" method=\"POST\">
  ";
        // line 5
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
  <input type=\"submit\">
</form>
";
        
        $__internal_00e43718ac8980fc5e6e3ab9eb412473fd278f1ab77b5575c40a1726b1dd285c->leave($__internal_00e43718ac8980fc5e6e3ab9eb412473fd278f1ab77b5575c40a1726b1dd285c_prof);

    }

    public function getTemplateName()
    {
        return "EventBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 5,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Hello World!


<form action=\"\" method=\"POST\">
  {{ form_widget(form) }}
  <input type=\"submit\">
</form>
", "EventBundle:Default:index.html.twig", "/Applications/MAMP/htdocs/hey/src/hey/EventBundle/Resources/views/Default/index.html.twig");
    }
}
