<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_ed304822071d27438ef075df7134786dc6ff79e1e2ed497429452f12c8164c60 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8f1c32114dcd9263d8c21d88d9868f573238c37493f5d0e354b8ce5d714dbcc4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8f1c32114dcd9263d8c21d88d9868f573238c37493f5d0e354b8ce5d714dbcc4->enter($__internal_8f1c32114dcd9263d8c21d88d9868f573238c37493f5d0e354b8ce5d714dbcc4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_8f1c32114dcd9263d8c21d88d9868f573238c37493f5d0e354b8ce5d714dbcc4->leave($__internal_8f1c32114dcd9263d8c21d88d9868f573238c37493f5d0e354b8ce5d714dbcc4_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.rdf.twig", "/Applications/MAMP/htdocs/hey/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
