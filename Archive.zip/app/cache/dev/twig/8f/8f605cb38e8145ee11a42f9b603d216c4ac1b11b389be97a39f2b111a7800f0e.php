<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_616296749ddd23c127416054c1efe3f10c699771f469713500b9ce6f241080e3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_450765aaca5e96a071bf97d25a82f5ff54f3fb29cd1639ee050f4cc6cf5cafed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_450765aaca5e96a071bf97d25a82f5ff54f3fb29cd1639ee050f4cc6cf5cafed->enter($__internal_450765aaca5e96a071bf97d25a82f5ff54f3fb29cd1639ee050f4cc6cf5cafed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_450765aaca5e96a071bf97d25a82f5ff54f3fb29cd1639ee050f4cc6cf5cafed->leave($__internal_450765aaca5e96a071bf97d25a82f5ff54f3fb29cd1639ee050f4cc6cf5cafed_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
", "@Framework/Form/url_widget.html.php", "/Applications/MAMP/htdocs/hey/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/url_widget.html.php");
    }
}
