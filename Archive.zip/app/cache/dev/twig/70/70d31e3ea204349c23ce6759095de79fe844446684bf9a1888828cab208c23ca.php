<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_2f90e3d083997407ccae609bcce500d059934eda0e97268bbe54fde2a31b6772 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_226b26d7fe5e50fe26e5ab2f6db90a64334c08137bfb03dd8af9a89dc28f7d4e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_226b26d7fe5e50fe26e5ab2f6db90a64334c08137bfb03dd8af9a89dc28f7d4e->enter($__internal_226b26d7fe5e50fe26e5ab2f6db90a64334c08137bfb03dd8af9a89dc28f7d4e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_226b26d7fe5e50fe26e5ab2f6db90a64334c08137bfb03dd8af9a89dc28f7d4e->leave($__internal_226b26d7fe5e50fe26e5ab2f6db90a64334c08137bfb03dd8af9a89dc28f7d4e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "/Applications/MAMP/htdocs/hey/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_row.html.php");
    }
}
