<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_9114989d1e5e3dd05a881f5ab285ffb0f1b97f6ecc3c242774a1a618c6f941e8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_513a595743af8cf69784fa7e4ea55d00479f4f421ace1fe7311e2d438c3d80b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_513a595743af8cf69784fa7e4ea55d00479f4f421ace1fe7311e2d438c3d80b3->enter($__internal_513a595743af8cf69784fa7e4ea55d00479f4f421ace1fe7311e2d438c3d80b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_513a595743af8cf69784fa7e4ea55d00479f4f421ace1fe7311e2d438c3d80b3->leave($__internal_513a595743af8cf69784fa7e4ea55d00479f4f421ace1fe7311e2d438c3d80b3_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_89c3ccf7494062743c3375a8f6c7e4c54ca9c1faaf96b56440740686714c118d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_89c3ccf7494062743c3375a8f6c7e4c54ca9c1faaf96b56440740686714c118d->enter($__internal_89c3ccf7494062743c3375a8f6c7e4c54ca9c1faaf96b56440740686714c118d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_89c3ccf7494062743c3375a8f6c7e4c54ca9c1faaf96b56440740686714c118d->leave($__internal_89c3ccf7494062743c3375a8f6c7e4c54ca9c1faaf96b56440740686714c118d_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_2095ea84e2d31a05eeabb36450584411d4caaf65376b92a3e6b42485d2e12396 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2095ea84e2d31a05eeabb36450584411d4caaf65376b92a3e6b42485d2e12396->enter($__internal_2095ea84e2d31a05eeabb36450584411d4caaf65376b92a3e6b42485d2e12396_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_2095ea84e2d31a05eeabb36450584411d4caaf65376b92a3e6b42485d2e12396->leave($__internal_2095ea84e2d31a05eeabb36450584411d4caaf65376b92a3e6b42485d2e12396_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_abfd3e7f54a9dcb03da241858a7e2c65fdeb1ac105264483d9ec9ba63a2c55be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_abfd3e7f54a9dcb03da241858a7e2c65fdeb1ac105264483d9ec9ba63a2c55be->enter($__internal_abfd3e7f54a9dcb03da241858a7e2c65fdeb1ac105264483d9ec9ba63a2c55be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_abfd3e7f54a9dcb03da241858a7e2c65fdeb1ac105264483d9ec9ba63a2c55be->leave($__internal_abfd3e7f54a9dcb03da241858a7e2c65fdeb1ac105264483d9ec9ba63a2c55be_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "WebProfilerBundle:Collector:router.html.twig", "/Applications/MAMP/htdocs/hey/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
