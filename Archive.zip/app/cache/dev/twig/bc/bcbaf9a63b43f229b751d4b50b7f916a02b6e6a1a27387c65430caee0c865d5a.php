<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_29d3c23052e17a2040af8b7eeee5ff930e05bb9b2f34d59ca26fe4f4ae05d545 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fa704a3901c395f424f282ed24d27558e2ea8b52b3aaee5f45b2415b1e7d6d0b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fa704a3901c395f424f282ed24d27558e2ea8b52b3aaee5f45b2415b1e7d6d0b->enter($__internal_fa704a3901c395f424f282ed24d27558e2ea8b52b3aaee5f45b2415b1e7d6d0b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_fa704a3901c395f424f282ed24d27558e2ea8b52b3aaee5f45b2415b1e7d6d0b->leave($__internal_fa704a3901c395f424f282ed24d27558e2ea8b52b3aaee5f45b2415b1e7d6d0b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "/Applications/MAMP/htdocs/hey/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_enctype.html.php");
    }
}
