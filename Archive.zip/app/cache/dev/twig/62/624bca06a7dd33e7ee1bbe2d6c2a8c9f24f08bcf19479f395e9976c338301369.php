<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_3ab1c4154e297974fa682dd86dff3bd79624a471bb313bdb5aae11f96aeaf970 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7237039c6b4fd334d64f87d685ac1425f166133598504a27344296a8f9d2d3c6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7237039c6b4fd334d64f87d685ac1425f166133598504a27344296a8f9d2d3c6->enter($__internal_7237039c6b4fd334d64f87d685ac1425f166133598504a27344296a8f9d2d3c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_7237039c6b4fd334d64f87d685ac1425f166133598504a27344296a8f9d2d3c6->leave($__internal_7237039c6b4fd334d64f87d685ac1425f166133598504a27344296a8f9d2d3c6_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_57eef4709b88a26e7d2d9c69c2ae8f01b851599e5268ae9a1860893b3ea02ae7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_57eef4709b88a26e7d2d9c69c2ae8f01b851599e5268ae9a1860893b3ea02ae7->enter($__internal_57eef4709b88a26e7d2d9c69c2ae8f01b851599e5268ae9a1860893b3ea02ae7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_57eef4709b88a26e7d2d9c69c2ae8f01b851599e5268ae9a1860893b3ea02ae7->leave($__internal_57eef4709b88a26e7d2d9c69c2ae8f01b851599e5268ae9a1860893b3ea02ae7_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "/Applications/MAMP/htdocs/hey/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
