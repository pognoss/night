<?php

/* TwigBundle:Exception:exception_full.html.twig */
class __TwigTemplate_ea7694bca1962e731ac2e7ecd414cea65639990ac8c13eadd7a27125f4315101 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "TwigBundle:Exception:exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_131c672a7afdcd85ee221e466fdcd2786307c8edfa5839a122530628c1865599 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_131c672a7afdcd85ee221e466fdcd2786307c8edfa5839a122530628c1865599->enter($__internal_131c672a7afdcd85ee221e466fdcd2786307c8edfa5839a122530628c1865599_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_131c672a7afdcd85ee221e466fdcd2786307c8edfa5839a122530628c1865599->leave($__internal_131c672a7afdcd85ee221e466fdcd2786307c8edfa5839a122530628c1865599_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_4c5c4be8aac989db383638cd863252690f9b9828740fe20bc1df0a6ddc9256b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c5c4be8aac989db383638cd863252690f9b9828740fe20bc1df0a6ddc9256b0->enter($__internal_4c5c4be8aac989db383638cd863252690f9b9828740fe20bc1df0a6ddc9256b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_4c5c4be8aac989db383638cd863252690f9b9828740fe20bc1df0a6ddc9256b0->leave($__internal_4c5c4be8aac989db383638cd863252690f9b9828740fe20bc1df0a6ddc9256b0_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_e80e4242a0e9604e453d0adb6b1c6cf04a7b1e762a5ca2f007f3d9b38cf33d59 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e80e4242a0e9604e453d0adb6b1c6cf04a7b1e762a5ca2f007f3d9b38cf33d59->enter($__internal_e80e4242a0e9604e453d0adb6b1c6cf04a7b1e762a5ca2f007f3d9b38cf33d59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_e80e4242a0e9604e453d0adb6b1c6cf04a7b1e762a5ca2f007f3d9b38cf33d59->leave($__internal_e80e4242a0e9604e453d0adb6b1c6cf04a7b1e762a5ca2f007f3d9b38cf33d59_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_edaeb8230e2c2ba789f2202bbe10256e68259ca4236f7c7c54dca079a82366fc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_edaeb8230e2c2ba789f2202bbe10256e68259ca4236f7c7c54dca079a82366fc->enter($__internal_edaeb8230e2c2ba789f2202bbe10256e68259ca4236f7c7c54dca079a82366fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "TwigBundle:Exception:exception_full.html.twig", 12)->display($context);
        
        $__internal_edaeb8230e2c2ba789f2202bbe10256e68259ca4236f7c7c54dca079a82366fc->leave($__internal_edaeb8230e2c2ba789f2202bbe10256e68259ca4236f7c7c54dca079a82366fc_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "TwigBundle:Exception:exception_full.html.twig", "/Applications/MAMP/htdocs/hey/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception_full.html.twig");
    }
}
