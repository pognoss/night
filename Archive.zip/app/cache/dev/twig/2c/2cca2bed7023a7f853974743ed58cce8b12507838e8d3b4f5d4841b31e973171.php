<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_a67fc00b1ed294dc9d308d5e6831d4610b01c5c1f874208ae69bb42c1b76c672 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_869efb9290269360f33831cd86bf1e906042713852dfb794f063e75654086a52 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_869efb9290269360f33831cd86bf1e906042713852dfb794f063e75654086a52->enter($__internal_869efb9290269360f33831cd86bf1e906042713852dfb794f063e75654086a52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_869efb9290269360f33831cd86bf1e906042713852dfb794f063e75654086a52->leave($__internal_869efb9290269360f33831cd86bf1e906042713852dfb794f063e75654086a52_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "/Applications/MAMP/htdocs/hey/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_label.html.php");
    }
}
